import{z as c,r as a,e as n,f as o,aF as d,am as u,$ as y}from"./index-CU6OOK94.js";import{a as s,u as m}from"./react-query-BkLD1H_6.js";import{d as p}from"./jotai-B6yoDLmd.js";/**
 * Invoice Ninja (https://invoiceninja.com).
 *
 * @link https://github.com/invoiceninja/invoiceninja source repository
 *
 * @copyright Copyright (c) 2022. Invoice Ninja LLC (https://invoiceninja.com)
 *
 * @license https://www.elastic.co/licensing/elastic-license
 */function h(e){return s(["/api/v1/payments",e],()=>a("GET",n("/api/v1/payments/:id?include=client,invoices,paymentables,:include",{id:e.id,include:e.include||""})).then(t=>t.data.data),{enabled:e.enabled??!0,staleTime:1/0})}function b(e){return s(["/api/v1/payments",e],()=>a("GET",n("/api/v1/payments?filter=:filter&per_page=:per_page&status=:status&page=:page&match_transactions=:match_transactions&include=:include",{per_page:e.perPage??"100",page:e.currentPage??"1",status:e.status??"active",filter:e.filter??"",match_transactions:e.matchTransactions??!1,include:e.include||""})).then(t=>t.data.data),{enabled:e.enabled??!0,staleTime:1/0})}function P(){const e=c();return s(o("/api/v1/payments/create"),()=>a("GET",n("/api/v1/payments/create")),{staleTime:1/0,enabled:e("create_payment")})}function Q(){const e=m(),t=p(d);return(r,i)=>{u.processing(),a("POST",n("/api/v1/payments/bulk"),{action:i,ids:r}).then(()=>{const l=i==="email"?"emaile":i;u.success(`${l}d_payment`),t&&e.invalidateQueries([t]),y(["payments"])})}}export{Q as a,h as b,b as c,P as u};
